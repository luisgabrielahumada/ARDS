# Changelog

## [8.0.3]

- Updated line-awesome package 

## [8.0.2]

### Improvement

- Improved css for the avatar

## [8.0.1]

### New Features

- Added sample formik widget

## [8.0.0]

### New Features

- Added brand new Backend
- New tab to mange users
- Social login
- Manage users functionality
- Update password route
- Reset password route
- Upload avatar
- Refactored architecture

## [7.3.2]

### Fix

- Fixed small calendar events

## [7.3.1]

### Update

- Updated documentation

## [7.3.0]

### New Features

- Brand new chat component

## [7.2.0]

### New Features

- New exquisite design

## [7.1.1]

### New Features

- Virtual Tour

## [7.1.0]

### New Features

- Theme customizer

## [7.0.1]

### Fixed

- Fix bugs and css improvements

## [7.0.0]

### Updated

- Removed Jquery from core layout

### New Features

- New charts
