React.render(
	<Parent />,
	document.getElementById('app')
);